All your html fixtures resides here.
