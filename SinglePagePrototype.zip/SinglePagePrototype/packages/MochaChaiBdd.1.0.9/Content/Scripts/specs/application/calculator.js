﻿var expect = chai.expect;

describe('calculator', function() {
    it('adds', function () {
        expect(1 + 1).to.equal(2);
    });
});