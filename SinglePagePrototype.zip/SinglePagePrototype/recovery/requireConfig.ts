module Configuration {

    export var RequireConfig: RequireConfig;

    RequireConfig = {
        baseUrl: "/Scripts/App",
        paths: {
            "text": "../External/text",
            "templates": "../../Templates"
        }
    };
}