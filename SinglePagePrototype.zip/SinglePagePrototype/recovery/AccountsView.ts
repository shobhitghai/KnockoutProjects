export = AccountsView;

import AccountsListViewModel = require("ViewModels/AccountsListViewModel");
import BindingEngine = require("BindingEngines/KOBindingEngine");
import AccountsRepository = require("Services/Repository/AccountsRepository");

class AccountsView implements application.IView {

    private data: Array<Model.Account>;
    private $element: JQuery;
    private viewModel: AccountsListViewModel;

    private bindingEngine: application.IBindingEngine;
    private accountsRepository: AccountsRepository;

    constructor() {        
        this.bindingEngine = new BindingEngine();
        this.accountsRepository = new AccountsRepository();
    }

    public Initialize($container: JQuery): AccountsView {
        this.$element = $("<div/>").appendTo($container);

        this.viewModel = new AccountsListViewModel([]);
        this.accountsRepository.LoadAccounts().done((accounts: Array<Model.Account>)=> {
            this.viewModel.accounts(accounts);
            (<any>this.viewModel.accounts).IsReady(true);
        });

        return this;
    }

    public Activate(): AccountsView {
        require(["text!templates/AccountsTemplates.htm"], (template) => {
            $("body").append(template);
            this.bindingEngine.bindTemplate("accountsListTemplate", this.$element, this.viewModel);        
        });        
        return this;
    }

    public Deactivate(): AccountsView {
        return this;
    }


    public Destroy(): AccountsView {
        this.$element.remove();
        return this;
    }

}