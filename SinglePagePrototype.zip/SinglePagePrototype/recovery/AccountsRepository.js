define(["require", "exports"], function(require, exports) {
    

    var AccountsRepository = (function () {
        function AccountsRepository() {
        }
        AccountsRepository.prototype.LoadAccounts = function () {
            var _this = this;
            var deferred = $.Deferred();
            var task = deferred.promise();
            task.Status = ko.observable();

            var timeout = window.setTimeout(function () {
                deferred.resolve(_this.getMockAccounts());
            }, 3000);

            task.then(function () {
                task.Status(application.AsyncTaskStatus.Completed);
            }, function () {
                task.Status(application.AsyncTaskStatus.Failed);
            });
            task.Cancel = function () {
                window.clearTimeout(timeout);
                task.Status(application.AsyncTaskStatus.Cancelled);
                return task;
            };

            return task;
        };

        AccountsRepository.prototype.getMockAccounts = function () {
            var arr = [
                {
                    Id: 1,
                    Name: "Nike",
                    KPIValue: 3.5
                },
                {
                    Id: 2,
                    Name: "American Express",
                    KPIValue: -5.6
                },
                {
                    Id: 3,
                    Name: "Ford corporate",
                    KPIValue: 2
                }
            ];
            return arr.toQuery().where(function (account) {
                return account.KPIValue > 0;
            }).take(1).toArray();
        };
        return AccountsRepository;
    })();
    return AccountsRepository;
});
//# sourceMappingURL=AccountsRepository.js.map
