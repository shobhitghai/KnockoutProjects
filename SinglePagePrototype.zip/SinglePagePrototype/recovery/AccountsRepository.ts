export = AccountsRepository;

import AjaxWrapper = require("Utils/AjaxWrapper");

class AccountsRepository {

    public LoadAccounts(): application.IAsyncTask<Model.Account> {
        
        var deferred = $.Deferred();
        var task: application.IAsyncTask<Model.Account> = <any>deferred.promise();
        task.Status = ko.observable<application.AsyncTaskStatus>();

        var timeout = window.setTimeout(() => {
            deferred.resolve(this.getMockAccounts());
        }, 3000);

        task.then(
            ()=> { task.Status(application.AsyncTaskStatus.Completed); },
            ()=> { task.Status(application.AsyncTaskStatus.Failed); }
        );
        task.Cancel = () => {
            window.clearTimeout(timeout);
            task.Status(application.AsyncTaskStatus.Cancelled);
            return task;
        };

        return task;
    }


    private getMockAccounts(): Array<Model.Account> {        
        var arr = [
            {
                Id: 1,
                Name: "Nike",
                KPIValue: 3.5
            },
            {
                Id: 2,
                Name: "American Express",
                KPIValue: -5.6
            },
            {
                Id: 3,
                Name: "Ford corporate",
                KPIValue: 2
            }
        ];
        return arr.toQuery().where((account) => {
             return account.KPIValue > 0;
        }).take(1).toArray();
    }

} 