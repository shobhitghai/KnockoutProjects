require.config(Configuration.RequireConfig);

require([
    "Views/GreeterView", "Views/GreetersListView",
    "Views/AccountsView", "Views/AccountsViewKendo", "text"], function (greeterView, greetersListView, accountsListView, accountsListViewKendo, text) {
    var el = $("#content");
    var view = null;
    var router = new kendo.Router();

    router.route("/", function () {
        if (view) {
            view.Deactivate().Destroy();
        }
        view = new greeterView();
        view.Initialize(el).Activate();
    });

    router.route("/multiple(/:count)", function (count) {
        if (view) {
            view.Deactivate().Destroy();
        }
        view = new greetersListView(count || 2);
        view.Initialize(el).Activate();
    });

    router.route("/accounts", function () {
        if (view) {
            view.Deactivate().Destroy();
        }
        view = new accountsListView();
        view.Initialize(el).Activate();
    });

    router.route("/accountsKendo", function () {
        if (view) {
            view.Deactivate().Destroy();
        }
        view = new accountsListViewKendo();
        view.Initialize(el).Activate();
    });

    router.start();
});
//# sourceMappingURL=app.js.map
