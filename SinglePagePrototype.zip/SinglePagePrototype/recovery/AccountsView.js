define(["require", "exports", "ViewModels/AccountsListViewModel", "BindingEngines/KOBindingEngine", "Services/Repository/AccountsRepository"], function(require, exports, AccountsListViewModel, BindingEngine, AccountsRepository) {
    

    var AccountsView = (function () {
        function AccountsView() {
            this.bindingEngine = new BindingEngine();
            this.accountsRepository = new AccountsRepository();
        }
        AccountsView.prototype.Initialize = function ($container) {
            var _this = this;
            this.$element = $("<div/>").appendTo($container);

            this.viewModel = new AccountsListViewModel([]);
            this.accountsRepository.LoadAccounts().done(function (accounts) {
                _this.viewModel.accounts(accounts);
                _this.viewModel.accounts.IsReady(true);
            });

            return this;
        };

        AccountsView.prototype.Activate = function () {
            var _this = this;
            require(["text!templates/AccountsTemplates.htm"], function (template) {
                $("body").append(template);
                _this.bindingEngine.bindTemplate("accountsListTemplate", _this.$element, _this.viewModel);
            });
            return this;
        };

        AccountsView.prototype.Deactivate = function () {
            return this;
        };

        AccountsView.prototype.Destroy = function () {
            this.$element.remove();
            return this;
        };
        return AccountsView;
    })();
    return AccountsView;
});
//# sourceMappingURL=AccountsView.js.map
