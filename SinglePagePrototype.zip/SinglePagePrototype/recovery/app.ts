require.config(Configuration.RequireConfig);


require(["Views/GreeterView", "Views/GreetersListView",
    "Views/AccountsView", "Views/AccountsViewKendo", "text"], (greeterView, greetersListView, accountsListView, accountsListViewKendo, text) => {   

    var el = $("#content");
    var view:application.IView = null;
    var router = new kendo.Router();

    router.route("/", () => {
        if (view) {
            view.Deactivate().Destroy();
        }
        view = new greeterView();
        view.Initialize(el).Activate();
    });

    router.route("/multiple(/:count)", (count: number) => {
        if (view) {
            view.Deactivate().Destroy();
        }        
        view = new greetersListView(count || 2);        
        view.Initialize(el).Activate();
    });

    router.route("/accounts", () => {
        if (view) {
            view.Deactivate().Destroy();
        }
        view = new accountsListView();
        view.Initialize(el).Activate();
    });

        router.route("/accountsKendo", () => {
            if (view) {
                view.Deactivate().Destroy();
            }
            view = new accountsListViewKendo();
            view.Initialize(el).Activate();
        });

    router.start();    
});