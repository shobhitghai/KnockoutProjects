﻿({    
    mainConfigFile:"app.js",
    modules: [
        {
            name: "app"
        }
    ]
})