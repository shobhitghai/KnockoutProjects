var Configuration;
(function (Configuration) {
    Configuration.RequireConfig;

    Configuration.RequireConfig = {
        baseUrl: "/Scripts/App",
        paths: {
            "text": "../External/text",
            "templates": "../../Templates"
        }
    };
})(Configuration || (Configuration = {}));
//# sourceMappingURL=RequireConfig.js.map
