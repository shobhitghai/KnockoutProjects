import Square = require("squire");
import AsyncTaskBuilderImpl = require("Utils/AsyncTaskBuilder");

export = TestContext;

class TestContext implements Tests.ITestContext {

    public AsyncTaskBuilder: application.IAsyncTaskBuilder;
    private Injector: any;

    constructor() {
        this.AsyncTaskBuilder = AsyncTaskBuilderImpl;
        this.Injector = new (<any>Square)();        
    }

    public MockInstance<T>(moduleName: string, mock: T) {
        this.Injector.mock(moduleName, mock);
    }

    public MockConstructor<T>(moduleName: string, mockObject: T) {
        this.Injector.mock(moduleName, ()=> { return mockObject; });
    }

    public Resolve<T>(moduleName: string, callback: (mod: T) => void) {
        this.Injector.require([moduleName], callback);
    }

    public GetAsyncTaskMock<T>(): Tests.AsyncTaskMock<T> {
        var deferred = $.Deferred();
        return {
            Deferred: deferred,
            Mock: sinon.stub().returns(this.AsyncTaskBuilder.FromPromise(deferred.promise()))
        };
    }
    
    public ClearMocks() {
        this.Injector.clean();
    }
}
