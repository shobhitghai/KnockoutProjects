export = TestContext;
declare class TestContext implements Tests.ITestContext {
    public AsyncTaskBuilder: application.IAsyncTaskBuilder;
    private Injector;
    constructor();
    public MockInstance<T>(moduleName: string, mock: T): void;
    public MockConstructor<T>(moduleName: string, mockObject: T): void;
    public Resolve<T>(moduleName: string, callback: (mod: T) => void): void;
    public GetAsyncTaskMock<T>(): Tests.AsyncTaskMock<T>;
    public ClearMocks(): void;
}
