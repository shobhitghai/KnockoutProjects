define(["require", "exports", "squire", "Utils/AsyncTaskBuilder"], function(require, exports, Square, AsyncTaskBuilderImpl) {
    

    var TestContext = (function () {
        function TestContext() {
            this.AsyncTaskBuilder = AsyncTaskBuilderImpl;
            this.Injector = new Square();
        }
        TestContext.prototype.MockInstance = function (moduleName, mock) {
            this.Injector.mock(moduleName, mock);
        };

        TestContext.prototype.MockConstructor = function (moduleName, mockObject) {
            this.Injector.mock(moduleName, function () {
                return mockObject;
            });
        };

        TestContext.prototype.Resolve = function (moduleName, callback) {
            this.Injector.require([moduleName], callback);
        };

        TestContext.prototype.GetAsyncTaskMock = function () {
            var deferred = $.Deferred();
            return {
                Deferred: deferred,
                Mock: sinon.stub().returns(this.AsyncTaskBuilder.FromPromise(deferred.promise()))
            };
        };

        TestContext.prototype.ClearMocks = function () {
            this.Injector.clean();
        };
        return TestContext;
    })();
    return TestContext;
});
//# sourceMappingURL=TestContext.js.map
