declare var expect: (target: any, message?: string) => chai.Expect;

declare module Tests {

    export interface ITestContext {

        AsyncTaskBuilder: application.IAsyncTaskBuilder;

        MockInstance<T>(moduleName: string, mock: T);

        MockConstructor<T>(moduleName: string, mockObject: T);

        Resolve<T>(moduleName: string, callback: (mod: T) => void);

        GetAsyncTaskMock<T>(): AsyncTaskMock<T>;

        ClearMocks(): void;
    }

    export interface AsyncTaskMock<T> {
        Mock: SinonStub;
        Deferred: JQueryDeferred<T>;
    }

}