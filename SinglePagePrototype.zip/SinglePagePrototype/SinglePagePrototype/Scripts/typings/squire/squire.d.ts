declare module "squire" {        
}