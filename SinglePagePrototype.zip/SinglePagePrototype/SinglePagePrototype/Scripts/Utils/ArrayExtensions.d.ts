interface Array<T> {
    toQuery(): linqjs.IEnumerable<T>;
}
