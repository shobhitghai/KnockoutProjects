export = asyncTaskBuilder;

class AsyncTaskBuilder implements application.IAsyncTaskBuilder {       

    public FromPromise<T>(promise: JQueryPromise<T>): application.AsyncTask<T> {
        var task: application.AsyncTask<T> = <any>promise;
        task.Status = ko.observable(application.AsyncTaskStatus.Pending);
        task.then(
            ()=> { task.Status(application.AsyncTaskStatus.Completed); },
            ()=> { task.Status(application.AsyncTaskStatus.Failed); }
            );
        return task;
    }

    public FromTimeout<T>(callback: Function, interval: number): application.AsyncTask<T> {

        return (()=> {

            var deferred = $.Deferred();
            var task = this.FromPromise(deferred.promise());

            var timeout = setTimeout(() => {
                var data = callback();
                deferred.resolve(data);                
            }, interval);
            task.Cancel = ()=> {
                clearTimeout(timeout);
                task.Status(application.AsyncTaskStatus.Cancelled);
                return task;
            };

            return task;
        })();
    }

}

var asyncTaskBuilder: application.IAsyncTaskBuilder = new AsyncTaskBuilder();