declare module advertising {
    class HttpVerb {
        static Post: string;
        static Get: string;
    }
}
