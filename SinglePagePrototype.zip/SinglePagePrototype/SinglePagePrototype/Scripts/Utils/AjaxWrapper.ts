export = AjaxWrapper;

import AsyncTaskBuilder = require("Utils/AsyncTaskBuilder");

class AjaxWrapper{

    public static AjaxJsonRequest<T>(url: string, requestType: string, data: any, isCacheEnabled?: boolean): application.AsyncTask<T> {
        isCacheEnabled = isCacheEnabled || false;
        var jqXHR = $.ajax({
            type: requestType,
            url: url,
            data: data,
            dataType: "json",
            cache: isCacheEnabled,
            contentType: "application/json",
            xhrFields: {
                withCredentials: true
            }
        });
        return AjaxWrapper.jqXHRtoAsyncTask(jqXHR);
    }

    private static jqXHRtoAsyncTask<T>(jqXHR: JQueryXHR): application.AsyncTask<T> {

        var task = AsyncTaskBuilder.FromPromise(<any>jqXHR);        
        task.Cancel = ()=> {
            jqXHR.abort();
            task.Status(application.AsyncTaskStatus.Cancelled);
            return task;
        };
        return task;
    }
}
