declare module application {
    interface IAsyncTaskBuilder {
        FromPromise<T>(promise: JQueryPromise<T>): application.AsyncTask<T>;
        FromTimeout<T>(callback: () => T, interval: number): application.AsyncTask<T>;
    }
}
