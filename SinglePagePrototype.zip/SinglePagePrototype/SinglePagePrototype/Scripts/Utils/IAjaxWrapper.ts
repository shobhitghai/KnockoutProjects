module advertising {
    export class HttpVerb {
        public static Post: string = "POST";
        public static Get: string = "GET";
    }

} 