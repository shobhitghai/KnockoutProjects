﻿define(["require", "exports"], function(require, exports) {
    

    var AsyncTaskBuilder = (function () {
        function AsyncTaskBuilder() {
        }
        AsyncTaskBuilder.prototype.FromPromise = function (promise) {
            var task = promise;
            task.Status = ko.observable(3 /* Pending */);
            task.then(function () {
                task.Status(4 /* Completed */);
            }, function () {
                task.Status(5 /* Failed */);
            });
            return task;
        };

        AsyncTaskBuilder.prototype.FromTimeout = function (callback, interval) {
            var _this = this;
            return (function () {
                var deferred = $.Deferred();
                var task = _this.FromPromise(deferred.promise());

                var timeout = setTimeout(function () {
                    var data = callback();
                    deferred.resolve(data);
                }, interval);
                task.Cancel = function () {
                    clearTimeout(timeout);
                    task.Status(6 /* Cancelled */);
                    return task;
                };

                return task;
            })();
        };
        return AsyncTaskBuilder;
    })();

    var asyncTaskBuilder = new AsyncTaskBuilder();
    return asyncTaskBuilder;
});
//# sourceMappingURL=AsyncTaskBuilder.js.map
