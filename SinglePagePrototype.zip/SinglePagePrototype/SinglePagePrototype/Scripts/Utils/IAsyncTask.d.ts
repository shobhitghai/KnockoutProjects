declare module application {

    export enum TaskPriority {
        VeryLow = 10,
        Low = 20,
        Normal = 30,
        High = 40,
        VeryHigh = 50,
        Critical = 60
    }

    export enum AsyncTaskStatus {
        NotStarted = 1,
        Queued = 2,
        Pending = 3,
        Completed = 4,
        Failed = 5,
        Cancelled = 6
    }

    export interface AsyncTask<T> extends JQueryPromise<T> {

        Priority(): TaskPriority;

        Priority(priority: TaskPriority): AsyncTask<T>;

        Status: KnockoutObservable<AsyncTaskStatus>;

        Cancel(): AsyncTask<T>;
     }

 }