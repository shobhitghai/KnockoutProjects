export = AjaxWrapper;
declare class AjaxWrapper {
    static AjaxJsonRequest<T>(url: string, requestType: string, data: any, isCacheEnabled?: boolean): application.AsyncTask<T>;
    private static jqXHRtoAsyncTask<T>(jqXHR);
}
