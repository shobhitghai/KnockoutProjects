interface Array<T> {
    toQuery(): linqjs.IEnumerable<T>;
} 

Array.prototype.toQuery = function() {
    return Enumerable.from(this);
}