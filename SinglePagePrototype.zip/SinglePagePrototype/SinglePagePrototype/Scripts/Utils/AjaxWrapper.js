define(["require", "exports", "Utils/AsyncTaskBuilder"], function(require, exports, AsyncTaskBuilder) {
    

    var AjaxWrapper = (function () {
        function AjaxWrapper() {
        }
        AjaxWrapper.AjaxJsonRequest = function (url, requestType, data, isCacheEnabled) {
            isCacheEnabled = isCacheEnabled || false;
            var jqXHR = $.ajax({
                type: requestType,
                url: url,
                data: data,
                dataType: "json",
                cache: isCacheEnabled,
                contentType: "application/json",
                xhrFields: {
                    withCredentials: true
                }
            });
            return AjaxWrapper.jqXHRtoAsyncTask(jqXHR);
        };

        AjaxWrapper.jqXHRtoAsyncTask = function (jqXHR) {
            var task = AsyncTaskBuilder.FromPromise(jqXHR);
            task.Cancel = function () {
                jqXHR.abort();
                task.Status(6 /* Cancelled */);
                return task;
            };
            return task;
        };
        return AjaxWrapper;
    })();
    return AjaxWrapper;
});
//# sourceMappingURL=AjaxWrapper.js.map
