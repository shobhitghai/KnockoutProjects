Array.prototype.toQuery = function () {
    return Enumerable.from(this);
};
//# sourceMappingURL=ArrayExtensions.js.map
