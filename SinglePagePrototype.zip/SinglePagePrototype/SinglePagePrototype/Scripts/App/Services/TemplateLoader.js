define(["require", "exports"], function(require, exports) {
    

    var TemplateLoader = (function () {
        function TemplateLoader() {
        }
        TemplateLoader.prototype.LoadTemplate = function (templateId, register, templateModuleName) {
            var _this = this;
            var deferred = $.Deferred();
            var task = deferred.promise();
            task.Status = ko.observable(3 /* Pending */);

            require(["text", "text!" + (templateModuleName || ("Templates/" + templateId + ".htm"))], function (text, template) {
                if (register) {
                    _this.RegisterTemplate(templateId, template);
                }
                deferred.resolve(template);
                task.Status(4 /* Completed */);
            }, function (error) {
                deferred.reject(error.message);
                task.Status(5 /* Failed */);
            });

            return task;
        };

        TemplateLoader.prototype.RegisterTemplate = function (templateId, template) {
            if ($("#" + templateId).length === 0) {
                $("body").append($.trim(template));
            }
        };
        return TemplateLoader;
    })();

    var templateLoaderInstance = new TemplateLoader();
    return templateLoaderInstance;
});
//# sourceMappingURL=TemplateLoader.js.map
