export = templateLoaderInstance;
declare var templateLoaderInstance: Services.ITemplateLoader;
