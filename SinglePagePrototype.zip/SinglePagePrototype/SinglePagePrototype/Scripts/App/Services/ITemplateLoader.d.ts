declare module Services {

    export interface ITemplateLoader {

        LoadTemplate(templateId: string, register: boolean, templateModuleName?: string): application.AsyncTask<string> 

        RegisterTemplate(templateId: string, template: string): void;        

    }
}