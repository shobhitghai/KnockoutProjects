define(["require", "exports"], function(require, exports) {
    

    var AjaxWrapper = (function () {
        function AjaxWrapper() {
        }
        AjaxWrapper.AjaxJsonRequest = function (url, requestType, data, isCacheEnabled) {
            isCacheEnabled = isCacheEnabled || false;
            var jqXHR = $.ajax({
                type: requestType,
                url: url,
                data: data,
                dataType: "json",
                cache: isCacheEnabled,
                contentType: "application/json",
                xhrFields: {
                    withCredentials: true
                }
            });
            return AjaxWrapper.jqXHRtoAsyncTask(jqXHR);
        };

        AjaxWrapper.jqXHRtoAsyncTask = function (jqXHR) {
            var task = jqXHR;
            task.Status = ko.observable(3 /* Pending */);
            task.then(function () {
                task.Status(4 /* Completed */);
            }, function () {
                task.Status(5 /* Failed */);
            });
            task.Cancel = function () {
                jqXHR.abort();
                return task;
            };
            return task;
        };
        return AjaxWrapper;
    })();
    return AjaxWrapper;
});
//# sourceMappingURL=ajaxWrapper.js.map
