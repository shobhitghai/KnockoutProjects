export = templateLoaderInstance;

class TemplateLoader implements Services.ITemplateLoader {
    
    public LoadTemplate(templateId: string, register: boolean, templateModuleName?: string): application.AsyncTask<string> {
        var deferred = $.Deferred();
        var task: application.AsyncTask<string> = <any>deferred.promise();
        task.Status = ko.observable(application.AsyncTaskStatus.Pending);

        require(["text", "text!" + (templateModuleName || ("Templates/" + templateId + ".htm"))],
            (text: any, template: string) => {
                if (register) {
                    this.RegisterTemplate(templateId, template);
                }
                deferred.resolve(template);
                task.Status(application.AsyncTaskStatus.Completed);
            },
            (error: RequireError)=> {
                deferred.reject(error.message);
                task.Status(application.AsyncTaskStatus.Failed);
            }
        );

        return task;
    }    

    public RegisterTemplate(templateId: string, template: string) {
        if ($("#" + templateId).length === 0) {
            $("body").append($.trim(template));
        }        
    }

}

var templateLoaderInstance: Services.ITemplateLoader = new TemplateLoader();