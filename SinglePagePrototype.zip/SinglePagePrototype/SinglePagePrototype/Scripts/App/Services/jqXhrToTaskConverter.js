var application;
(function (application) {
    var originalAjax = $.ajax;

    var wrappedAjax = function () {
        originalAjax.apply($, arguments);
    };

    $.ajax = (function () {
    });
})(application || (application = {}));
//# sourceMappingURL=jqXhrToTaskConverter.js.map
