define(["require", "exports"], function(require, exports) {
    

    var AdvertisersRepository = (function () {
        function AdvertisersRepository() {
        }
        AdvertisersRepository.prototype.GetAllAdvertisers = function () {
            throw new Error("Not implemented");
        };

        AdvertisersRepository.prototype.GetAdvertiser = function (advertiserId) {
            throw new Error("Not implemented");
        };
        return AdvertisersRepository;
    })();
    return AdvertisersRepository;
});
//# sourceMappingURL=AdvetisersRepository.js.map
