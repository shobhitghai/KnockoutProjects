export = AccountsRepository;
declare class AccountsRepository implements Services.IAccountsRepository {
    public GetAllAccounts(): application.AsyncTask<Model.Account>;
    public GetAdvertiserAccounts(advertiserId: number): application.AsyncTask<Model.Account[]>;
}
