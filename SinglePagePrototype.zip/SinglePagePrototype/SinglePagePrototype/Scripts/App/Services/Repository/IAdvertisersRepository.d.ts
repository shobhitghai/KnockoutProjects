declare module Services {

    export interface IAdvertisersRepository {

        GetAllAdvertisers(): application.AsyncTask<Array<Model.Advertiser>>;

        GetAdvertiser(advertiserId: number): application.AsyncTask<Model.Advertiser>;
    }
} 