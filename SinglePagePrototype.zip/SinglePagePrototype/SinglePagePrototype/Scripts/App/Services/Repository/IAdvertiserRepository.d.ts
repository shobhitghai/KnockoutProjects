declare module Services {
    interface IAdvertisersRepository {
        GetAllAddvertisers(): application.AsyncTask<Model.Advertiser[]>;
        GetAddvertiser(advertiserId: number): application.AsyncTask<Model.Advertiser>;
    }
}
