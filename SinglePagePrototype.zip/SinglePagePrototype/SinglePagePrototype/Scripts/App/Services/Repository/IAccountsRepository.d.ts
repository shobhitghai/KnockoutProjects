declare module Services {

    export interface IAccountsRepository {

        GetAllAccounts(): application.AsyncTask<Array<Model.Account>>;        

        GetAdvertiserAccounts(advertiserId: number): application.AsyncTask<Array<Model.Account>>;
    }
} 