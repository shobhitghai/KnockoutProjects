export = AdvertisersRepository;

class AdvertisersRepository implements Services.IAdvertisersRepository {
    
    GetAllAdvertisers(): application.AsyncTask<Array<Model.Advertiser>> {
        throw new Error("Not implemented");
    }

    GetAdvertiser(advertiserId: number): application.AsyncTask<Model.Advertiser> {
        throw new Error("Not implemented");
    }
} 