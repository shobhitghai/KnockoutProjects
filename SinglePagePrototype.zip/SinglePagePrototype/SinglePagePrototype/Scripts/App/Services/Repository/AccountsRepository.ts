export = AccountsRepository;

class AccountsRepository implements Services.IAccountsRepository {
    
    public GetAllAccounts(): application.AsyncTask<Model.Account> {
        throw new Error("Not implemented");
    }

    public GetAdvertiserAccounts(advertiserId: number): application.AsyncTask<Array<Model.Account>> {
        throw new Error("Not implemented");
    }
} 