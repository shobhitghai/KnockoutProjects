define(["require", "exports"], function(require, exports) {
    

    var AccountsRepository = (function () {
        function AccountsRepository() {
        }
        AccountsRepository.prototype.GetAllAccounts = function () {
            throw new Error("Not implemented");
        };

        AccountsRepository.prototype.GetAdvertiserAccounts = function (advertiserId) {
            throw new Error("Not implemented");
        };
        return AccountsRepository;
    })();
    return AccountsRepository;
});
//# sourceMappingURL=AccountsRepository.js.map
