var advertising;
(function (advertising) {
    var HttpVerb = (function () {
        function HttpVerb() {
        }
        HttpVerb.Post = "POST";
        HttpVerb.Get = "GET";
        return HttpVerb;
    })();
    advertising.HttpVerb = HttpVerb;
})(advertising || (advertising = {}));
//# sourceMappingURL=IAjaxWrapper.js.map
