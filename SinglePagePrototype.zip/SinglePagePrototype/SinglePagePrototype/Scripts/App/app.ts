/// <amd-dependency path="text" />

import Router = require("Configuration/Router");

var router = new Router($("#content"));
router.Start();