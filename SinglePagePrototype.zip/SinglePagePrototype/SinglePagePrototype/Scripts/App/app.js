/// <amd-dependency path="text" />
define(["require", "exports", "Configuration/Router", "text"], function(require, exports, Router) {
    var router = new Router($("#content"));
    router.Start();
});
//# sourceMappingURL=app.js.map
