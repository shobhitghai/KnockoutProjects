export = KendoBindingEngine;
declare class KendoBindingEngine implements application.IBindingEngine {
    public bind($element: JQuery, viewModel: any): KendoBindingEngine;
    public bindTemplate(templateId: string, $element: JQuery, viewModel: any, templateModuleName?: string): application.AsyncTask<string>;
}
