export = KendoBindingEngine;

import TemplateLoader = require("Services/TemplateLoader");

class KendoBindingEngine implements application.IBindingEngine {    

    public bind($element: JQuery, viewModel: any): KendoBindingEngine {        
        kendo.bind($element[0], viewModel);
        return this;
    }

    public bindTemplate(templateId: string, $element: JQuery, viewModel: any, templateModuleName?: string): application.AsyncTask<string> {

        var templateTask = TemplateLoader.LoadTemplate(templateId, true, templateModuleName);

        templateTask.done(() => {            
            $element.html($("#" + templateId).html());
            this.bind($element, viewModel);
        });

        return templateTask;
    }
} 