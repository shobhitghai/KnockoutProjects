export = KOBindingEngine;

import TemplateLoader = require("Services/TemplateLoader");

class KOBindingEngine implements application.IBindingEngine {    

    public bind($element: JQuery, viewModel: any): KOBindingEngine {        
        ko.applyBindings(viewModel, $element[0]);
        return this;
    }

    public bindTemplate(templateId: string, $element: JQuery, viewModel: any, templateModuleName?: string): application.AsyncTask<any> {

        var templateTask = TemplateLoader.LoadTemplate(templateId, true, templateModuleName);

        templateTask.done(() => {
            $element.html($("#" + templateId).html());
            this.bind($element, viewModel);
        });

        return templateTask;
    }
}