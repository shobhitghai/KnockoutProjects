define(["require", "exports", "Services/TemplateLoader"], function(require, exports, TemplateLoader) {
    

    var KendoBindingEngine = (function () {
        function KendoBindingEngine() {
        }
        KendoBindingEngine.prototype.bind = function ($element, viewModel) {
            kendo.bind($element[0], viewModel);
            return this;
        };

        KendoBindingEngine.prototype.bindTemplate = function (templateId, $element, viewModel, templateModuleName) {
            var _this = this;
            var templateTask = TemplateLoader.LoadTemplate(templateId, true, templateModuleName);

            templateTask.done(function () {
                $element.html($("#" + templateId).html());
                _this.bind($element, viewModel);
            });

            return templateTask;
        };
        return KendoBindingEngine;
    })();
    return KendoBindingEngine;
});
//# sourceMappingURL=KendoBindingEngine.js.map
