define(["require", "exports", "Services/TemplateLoader"], function(require, exports, TemplateLoader) {
    

    var KOBindingEngine = (function () {
        function KOBindingEngine() {
        }
        KOBindingEngine.prototype.bind = function ($element, viewModel) {
            ko.applyBindings(viewModel, $element[0]);
            return this;
        };

        KOBindingEngine.prototype.bindTemplate = function (templateId, $element, viewModel, templateModuleName) {
            var _this = this;
            var templateTask = TemplateLoader.LoadTemplate(templateId, true, templateModuleName);

            templateTask.done(function () {
                $element.html($("#" + templateId).html());
                _this.bind($element, viewModel);
            });

            return templateTask;
        };
        return KOBindingEngine;
    })();
    return KOBindingEngine;
});
//# sourceMappingURL=KOBindingEngine.js.map
