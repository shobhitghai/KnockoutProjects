export = KOBindingEngine;
declare class KOBindingEngine implements application.IBindingEngine {
    public bind($element: JQuery, viewModel: any): KOBindingEngine;
    public bindTemplate(templateId: string, $element: JQuery, viewModel: any, templateModuleName?: string): application.AsyncTask<any>;
}
