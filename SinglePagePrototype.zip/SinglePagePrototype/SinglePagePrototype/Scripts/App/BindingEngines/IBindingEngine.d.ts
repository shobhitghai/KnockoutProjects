//Interface for binding engine. Allows to use different binding techniques in different cases
declare module application {

    export interface BindingEngineConstructor {
        new () : IBindingEngine;        
    }

    export interface IBindingEngine {

        // Bind viewModel to an existing element
        bind($element: JQuery, viewModel: any): IBindingEngine;

        // Bind template, specified by template Id to an element. Loads template so expected to be async in some cases
        bindTemplate(templateId: string, $element: JQuery, viewModel: any, templateModuleName?: string): AsyncTask<any>;

    }
} 