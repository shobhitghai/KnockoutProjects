﻿var require = {
    baseUrl: "Scripts/App",
    paths: {
        "App": "./",
        "External": "../External",
        "Mocks": "../Mocks",
        "DataBuilders": "../Mocks/DataBuilders",
        "Utils": "../Utils",
        "text": "../External/text"
    },

    map: {
        // Mocks
        "*" : {
            "Services/Repository/AccountsRepository": "Mocks/Services/AccountsRepositoryMockData",
            "Services/Repository/AdvertisersRepository": "Mocks/Services/AdvertisersRepositoryMockData"
        }
    }
};
