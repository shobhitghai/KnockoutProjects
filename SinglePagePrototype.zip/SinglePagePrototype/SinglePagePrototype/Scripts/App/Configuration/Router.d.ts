export = Router;
declare class Router {
    private $contentElement;
    private contentView;
    private kendoRouter;
    constructor($contentElement: JQuery);
    public Start(): void;
    private SetupRouter();
    private registerRoute(route, viewConstructor);
}
