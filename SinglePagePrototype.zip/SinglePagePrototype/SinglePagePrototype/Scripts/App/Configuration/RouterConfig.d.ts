export = RouterConfig;
declare class RouterConfig {
    private static activeView;
    static SetupRouter(): kendo.Router;
    private static switchView(viewConstructor, $element);
}
