define(["require", "exports", "Views/GreeterView", "Views/AdvertisersView", "Views/AccountsView", "Views/AccountsViewKendo"], function(require, exports, GreeterView, AdvertisersView, AccountsView, AccountsViewKendo) {
    

    var Router = (function () {
        function Router($contentElement) {
            this.$contentElement = $contentElement;
            this.kendoRouter = new kendo.Router();
            this.SetupRouter();
        }
        Router.prototype.Start = function () {
            this.kendoRouter.start();
        };

        Router.prototype.SetupRouter = function () {
            var router = new kendo.Router();

            this.registerRoute("/", function () {
                return new AccountsView();
            });
            this.registerRoute("/Accounts(/:advertiserId)", function (advertiserId) {
                return new AccountsView(advertiserId);
            });
            this.registerRoute("/Advertisers", function () {
                return new AdvertisersView();
            });

            return router;
        };

        Router.prototype.registerRoute = function (route, viewConstructor) {
            var _this = this;
            this.kendoRouter.route(route, function () {
                if (_this.contentView) {
                    _this.contentView.Destroy();
                }

                _this.contentView = viewConstructor.apply(_this, arguments);

                _this.contentView.Initialize(_this.$contentElement);
            });
        };
        return Router;
    })();
    return Router;
});
//# sourceMappingURL=Router.js.map
