define(["require", "exports", "Views/GreeterView", "Views/AdvertisersView", "Views/AccountsView"], function(require, exports, GreeterView, AdvertisersView, AccountsView) {
    

    var RouterConfig = (function () {
        function RouterConfig() {
        }
        RouterConfig.SetupRouter = function () {
            var el = $("#content");
            var view;
            var router = new kendo.Router();

            router.route("/", function () {
                if (view) {
                    view.Deactivate().Destroy();
                }
                view = new GreeterView();
                view.Initialize(el).Activate();
            });

            router.route("/Accounts(/:advertiserId)", function (advertiserId) {
                RouterConfig.switchView(function () {
                    return new AccountsView(advertiserId);
                }, el);
            });

            router.route("/Advertisers", function () {
                RouterConfig.switchView(function () {
                    return new AdvertisersView();
                }, el);
            });
            return router;
        };

        RouterConfig.switchView = function (viewConstructor, $element) {
            if (RouterConfig.activeView) {
                RouterConfig.activeView.Destroy();
            }
            RouterConfig.activeView = viewConstructor().Initialize($element);
        };
        return RouterConfig;
    })();
    return RouterConfig;
});
//# sourceMappingURL=RouterConfig.js.map
