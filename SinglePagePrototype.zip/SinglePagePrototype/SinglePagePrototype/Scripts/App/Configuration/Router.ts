
import GreeterView = require("Views/GreeterView");
import AdvertisersView = require("Views/AdvertisersView");
import AccountsView = require("Views/AccountsView");
import AccountsViewKendo = require("Views/AccountsViewKendo");

export = Router;

class Router {

    private contentView: application.IView;    
    private kendoRouter: kendo.Router;    

    constructor(private $contentElement: JQuery) {
        this.kendoRouter = new kendo.Router();
        this.SetupRouter();
    }    

    public Start() {
        this.kendoRouter.start();
    }

    private SetupRouter(): kendo.Router {
        
        var router = new kendo.Router();

        this.registerRoute("/", () => { return new AccountsView(); });
        this.registerRoute("/Accounts(/:advertiserId)", (advertiserId?: number) => { return new AccountsView(advertiserId); });
        this.registerRoute("/Advertisers", () => { return new AdvertisersView(); });        

        return router;
    }

    private registerRoute(route: string, viewConstructor: (...args: Array<any>) => application.IView) {
        this.kendoRouter.route(route, () => {            

            if(this.contentView){
                this.contentView.Destroy();
            }
            
            this.contentView = viewConstructor.apply(this,arguments);

            this.contentView.Initialize(this.$contentElement);
        });        
    }
       
}