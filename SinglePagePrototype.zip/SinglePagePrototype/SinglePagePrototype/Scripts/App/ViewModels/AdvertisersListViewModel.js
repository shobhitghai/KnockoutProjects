define(["require", "exports"], function(require, exports) {
    

    var AdvertisersListViewModel = (function () {
        function AdvertisersListViewModel() {
            this.Advertisers = ko.observable([]);
            this.IsReady = ko.observable(false);
            this.Header = Resources["AllAdvertisers"];
        }
        return AdvertisersListViewModel;
    })();
    return AdvertisersListViewModel;
});
//# sourceMappingURL=AdvertisersListViewModel.js.map
