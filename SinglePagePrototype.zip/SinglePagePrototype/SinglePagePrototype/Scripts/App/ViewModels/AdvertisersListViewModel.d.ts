export = AdvertisersListViewModel;
declare class AdvertisersListViewModel {
    public Advertisers: KnockoutObservable<Model.Advertiser[]>;
    public IsReady: KnockoutObservable<boolean>;
    public Header: string;
    constructor();
}
