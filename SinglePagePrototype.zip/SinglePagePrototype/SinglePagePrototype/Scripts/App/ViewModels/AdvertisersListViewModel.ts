export = AdvertisersListViewModel;

class AdvertisersListViewModel {

    public Advertisers: KnockoutObservable<Array<Model.Advertiser>>;
    public IsReady: KnockoutObservable<boolean>;   
    public Header: string;

    constructor() {
        this.Advertisers = ko.observable([]);
        this.IsReady = ko.observable(false);
        this.Header = Resources["AllAdvertisers"];
    }
} 