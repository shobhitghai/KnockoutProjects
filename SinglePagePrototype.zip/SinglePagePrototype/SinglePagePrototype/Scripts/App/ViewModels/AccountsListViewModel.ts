export = AccountsListViewModel;

class AccountsListViewModel {
    
    public Accounts: KnockoutObservable<Array<Model.Account>>;
    public IsReady: KnockoutObservable<boolean>;
    public Advertiser: KnockoutObservable<Model.Advertiser>;
    public AdvertiserLabel: KnockoutComputed<string>;

    constructor(advertiserId: number) {
        this.Accounts = ko.observable([]);
        this.IsReady = ko.observable(false);

        
        if (advertiserId) {
            this.Advertiser = ko.observable(null);
        }

        this.AdvertiserLabel = ko.computed(()=> {
            return (!advertiserId) ? Resources["AllAccounts"] :
            (Resources["AdvertiserAccounts"] + " - " + (this.Advertiser() ? this.Advertiser().CustomerName : Resources["Loading"]));
        });
    }    
} 