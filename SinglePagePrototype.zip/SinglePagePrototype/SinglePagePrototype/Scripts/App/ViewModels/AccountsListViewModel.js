define(["require", "exports"], function(require, exports) {
    

    var AccountsListViewModel = (function () {
        function AccountsListViewModel(advertiserId) {
            var _this = this;
            this.Accounts = ko.observable([]);
            this.IsReady = ko.observable(false);

            if (advertiserId) {
                this.Advertiser = ko.observable(null);
            }

            this.AdvertiserLabel = ko.computed(function () {
                return (!advertiserId) ? Resources["AllAccounts"] : (Resources["AdvertiserAccounts"] + " - " + (_this.Advertiser() ? _this.Advertiser().CustomerName : Resources["Loading"]));
            });
        }
        return AccountsListViewModel;
    })();
    return AccountsListViewModel;
});
//# sourceMappingURL=AccountsListViewModel.js.map
