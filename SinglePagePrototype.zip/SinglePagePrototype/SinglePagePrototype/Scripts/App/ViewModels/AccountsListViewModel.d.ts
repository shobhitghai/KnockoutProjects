export = AccountsListViewModel;
declare class AccountsListViewModel {
    public Accounts: KnockoutObservable<Model.Account[]>;
    public IsReady: KnockoutObservable<boolean>;
    public Advertiser: KnockoutObservable<Model.Advertiser>;
    public AdvertiserLabel: KnockoutComputed<string>;
    constructor(advertiserId: number);
}
