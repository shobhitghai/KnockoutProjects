declare module Model {
    
    export interface Advertiser {
        CustomerId: number;
        CustomerName: string;
        AccountManager: string;
        Country: string;
        Language: string;
        Accounts: Array<Model.Account>
    }
} 