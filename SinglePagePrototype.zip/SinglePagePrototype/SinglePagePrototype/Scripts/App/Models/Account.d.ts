declare module Model {
    // Model is a set of Plain data model declarations.
    // Represent application entities
    // Acts as interface between Server and UI services, UI Services and Views
    export enum AccountStatus {
        Draft = 1,
        Active = 2,
        Inactive = 3,
        Pause = 4,
        Pending = 5            
    }

    export interface Account {
        AccountName: string;
        AccountNumber: string;
        CustomerId: number;
        CustomerName: string;
        AccountStatus: AccountStatus;
    }
} 