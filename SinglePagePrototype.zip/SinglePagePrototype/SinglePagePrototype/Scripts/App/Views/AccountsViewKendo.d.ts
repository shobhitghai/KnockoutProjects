export = AccountsView;
declare class AccountsView implements application.IView {
    private data;
    private $element;
    public ViewModel: kendo.data.ObservableObject;
    private bindingEngine;
    private accountsRepository;
    constructor();
    public Initialize($container: JQuery): AccountsView;
    public Activate(): AccountsView;
    public Deactivate(): AccountsView;
    public Destroy(): AccountsView;
}
