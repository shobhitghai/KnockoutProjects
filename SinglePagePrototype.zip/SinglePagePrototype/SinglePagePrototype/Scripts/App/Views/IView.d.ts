declare module application {
    export interface IView {

        Initialize($container: JQuery): IView;

        Activate(): IView;

        Deactivate(): IView;

        Destroy(): IView;
    }
}
