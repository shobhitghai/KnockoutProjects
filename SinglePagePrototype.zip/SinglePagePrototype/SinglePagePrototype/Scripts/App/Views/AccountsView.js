define(["require", "exports", "ViewModels/AccountsListViewModel", "BindingEngines/KOBindingEngine", "Services/Repository/AccountsRepository", "Services/Repository/AdvertisersRepository", "text!Templates/AccountsListTemplate.htm"], function(require, exports, AccountsListViewModel, BindingEngine, AccountsRepository, AdvertisersRepository) {
    

    // User interface logic for Accounts list view
    var AccountsView = (function () {
        function AccountsView(advertiserId) {
            this.advertiserId = advertiserId;
            this.bindingEngine = new BindingEngine();
            this.accountsRepository = new AccountsRepository();
            this.advertisersRepository = new AdvertisersRepository();
        }
        // Public interface members
        AccountsView.prototype.Initialize = function ($container) {
            // Prepare container
            this.$element = $("<div/>").appendTo($container);

            // Initialize ViewModel
            this.ViewModel = new AccountsListViewModel(this.advertiserId);

            // Initiate data loading
            this.LoadAccounts();
            this.LoadAdvertiser();

            // Bind template
            this.bindingEngine.bindTemplate("AccountsListTemplate", this.$element, this.ViewModel);

            return this;
        };

        AccountsView.prototype.Activate = function () {
            return this;
        };

        AccountsView.prototype.Deactivate = function () {
            return this;
        };

        AccountsView.prototype.Destroy = function () {
            this.$element.remove();
            return this;
        };

        AccountsView.prototype.LoadAccounts = function () {
            var _this = this;
            var dataTask = this.advertiserId ? this.accountsRepository.GetAdvertiserAccounts(this.advertiserId) : this.accountsRepository.GetAllAccounts();

            dataTask.done(function (accounts) {
                _this.ViewModel.Accounts(accounts);
                _this.ViewModel.IsReady(true);
            });
        };

        AccountsView.prototype.LoadAdvertiser = function () {
            var _this = this;
            if (this.advertiserId) {
                this.advertisersRepository.GetAdvertiser(this.advertiserId).done(function (advetiser) {
                    _this.ViewModel.Advertiser(advetiser);
                });
            }
        };
        return AccountsView;
    })();
    return AccountsView;
});
//# sourceMappingURL=AccountsView.js.map
