/// <amd-dependency path="text!Templates/AccountsListTemplate.htm" />
export = AccountsView;

// Dependencies
import AccountsListViewModel = require("ViewModels/AccountsListViewModel");
import BindingEngine = require("BindingEngines/KOBindingEngine");
import AccountsRepository = require("Services/Repository/AccountsRepository");
import AdvertisersRepository = require("Services/Repository/AdvertisersRepository");

// User interface logic for Accounts list view
class AccountsView implements application.IView {
    
    // Public fields
    public ViewModel: AccountsListViewModel;

    // Private fields
    private $element: JQuery;    
    private bindingEngine: application.IBindingEngine;
    private accountsRepository: AccountsRepository;
    private advertisersRepository: AdvertisersRepository;

    constructor(private advertiserId?: number) {
        this.bindingEngine = new BindingEngine();
        this.accountsRepository = new AccountsRepository();
        this.advertisersRepository = new AdvertisersRepository();
    }

    // Public interface members
    public Initialize($container: JQuery): AccountsView {
        // Prepare container
        this.$element = $("<div/>").appendTo($container);        
        // Initialize ViewModel
        this.ViewModel = new AccountsListViewModel(this.advertiserId);        
        // Initiate data loading
        this.LoadAccounts();
        this.LoadAdvertiser();
        // Bind template
        this.bindingEngine.bindTemplate("AccountsListTemplate", this.$element, this.ViewModel);        

        return this;
    }

    public Activate(): AccountsView {
        return this;
    }

    public Deactivate(): AccountsView {
        return this;
    }


    public Destroy(): AccountsView {
        this.$element.remove();
        return this;
    }
    
    private LoadAccounts() {
        
        var dataTask = this.advertiserId
            ? this.accountsRepository.GetAdvertiserAccounts(this.advertiserId)
            : this.accountsRepository.GetAllAccounts();

        dataTask.done((accounts: Array<Model.Account>) => {
            this.ViewModel.Accounts(accounts);
            this.ViewModel.IsReady(true);        
        });
    }

    private LoadAdvertiser() {
        if (this.advertiserId) {
            this.advertisersRepository.GetAdvertiser(this.advertiserId).done((advetiser) => {
                this.ViewModel.Advertiser(advetiser);
            });
        }
    }
}