define(["require", "exports"], function(require, exports) {
    

    var GreeterView = (function () {
        function GreeterView() {
        }
        GreeterView.prototype.Initialize = function ($container) {
            this.$element = $("<div/>").text("The time is: ");
            this.$span = $("<span/>").text(new Date().toUTCString()).appendTo(this.$element);
            this.$element.appendTo($container);
            return this;
        };

        GreeterView.prototype.Activate = function () {
            var _this = this;
            if (!this.$element) {
                throw new Error("View must be initialized before it can be activated");
            }
            this.timerToken = setInterval(function () {
                return _this.$span.text(new Date().toUTCString());
            }, 500);
            return this;
        };

        GreeterView.prototype.Deactivate = function () {
            clearTimeout(this.timerToken);
            return this;
        };

        GreeterView.prototype.Destroy = function () {
            this.Deactivate();
            this.$element.remove();
            return this;
        };
        return GreeterView;
    })();
    return GreeterView;
});
//# sourceMappingURL=GreeterView.js.map
