define(["require", "exports", "ViewModels/AccountsListViewModel", "BindingEngines/KendoBindingEngine", "Services/Repository/AccountsRepository"], function(require, exports, AccountsListViewModel, BindingEngine, AccountsRepository) {
    

    var AccountsView = (function () {
        function AccountsView() {
            this.bindingEngine = new BindingEngine();
            this.accountsRepository = new AccountsRepository();
        }
        AccountsView.prototype.Initialize = function ($container) {
            var _this = this;
            this.$element = $("<div/>").appendTo($container);
            this.ViewModel = kendo.observable({ accounts: [] });
            this.accountsRepository.GetAllAccounts().done(function (data) {
                _this.ViewModel = kendo.observable({ accounts: data });
                _this.Activate();
            });
            return this;
        };

        AccountsView.prototype.Activate = function () {
            if (this.ViewModel.Accounts.length > 0) {
                this.bindingEngine.bindTemplate("accountsListTemplateKendo", this.$element, this.ViewModel);
            }
            return this;
        };

        AccountsView.prototype.Deactivate = function () {
            return this;
        };

        AccountsView.prototype.Destroy = function () {
            this.$element.remove();
            return this;
        };
        return AccountsView;
    })();
    return AccountsView;
});
//# sourceMappingURL=AccountsViewKendo.js.map
