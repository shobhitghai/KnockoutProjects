define(["require", "exports", "Views/GreeterView"], function(require, exports, GreeterImpl) {
    

    var GreetersListView = (function () {
        function GreetersListView(count) {
            this.count = count;
            this.greeters = new Array();
            for (var i = 0; i < count; i++) {
                var greeter = new GreeterImpl();
                this.greeters.push(greeter);
            }
        }
        GreetersListView.prototype.Initialize = function ($container) {
            $.each(this.greeters, function (index, greeter) {
                greeter.Initialize($container);
            });
            return this;
        };

        GreetersListView.prototype.Activate = function () {
            $.each(this.greeters, function (index, greeter) {
                greeter.Activate();
            });
            return this;
        };

        GreetersListView.prototype.Deactivate = function () {
            $.each(this.greeters, function (index, greeter) {
                greeter.Deactivate();
            });
            return this;
        };

        GreetersListView.prototype.Destroy = function () {
            $.each(this.greeters, function (index, greeter) {
                greeter.Destroy();
            });
            return this;
        };
        return GreetersListView;
    })();
    return GreetersListView;
});
//# sourceMappingURL=GreetersListView.js.map
