define(["require", "exports", "ViewModels/AdvertisersListViewModel", "BindingEngines/KOBindingEngine", "Services/Repository/AdvertisersRepository", "text!Templates/AdvertisersListTemplate.htm"], function(require, exports, AdvertisersListViewModel, BindingEngine, AdvertisersRepository) {
    

    var AdvertisersView = (function () {
        function AdvertisersView() {
            this.bindingEngine = new BindingEngine();
            this.advertisersRepository = new AdvertisersRepository();
        }
        AdvertisersView.prototype.Initialize = function ($container) {
            var _this = this;
            this.$element = $("<div/>").appendTo($container);

            this.ViewModel = new AdvertisersListViewModel();
            this.advertisersRepository.GetAllAdvertisers().done(function (advertisers) {
                _this.ViewModel.Advertisers(advertisers);
                _this.ViewModel.IsReady(true);
            });

            this.bindingEngine.bindTemplate("AdvertisersListTemplate", this.$element, this.ViewModel);

            return this;
        };

        AdvertisersView.prototype.Activate = function () {
            return this;
        };

        AdvertisersView.prototype.Deactivate = function () {
            return this;
        };

        AdvertisersView.prototype.Destroy = function () {
            this.$element.remove();
            return this;
        };
        return AdvertisersView;
    })();
    return AdvertisersView;
});
//# sourceMappingURL=AdvertisersView.js.map
