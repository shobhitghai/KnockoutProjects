/// <amd-dependency path="text!Templates/AdvertisersListTemplate.htm" />
export = AdvertisersView;

import AdvertisersListViewModel = require("ViewModels/AdvertisersListViewModel");
import BindingEngine = require("BindingEngines/KOBindingEngine");
import AdvertisersRepository = require("Services/Repository/AdvertisersRepository");

class AdvertisersView implements application.IView {
    
    private $element: JQuery;
    public ViewModel: AdvertisersListViewModel;

    private bindingEngine: application.IBindingEngine;    
    private advertisersRepository: AdvertisersRepository;

    constructor() {
        this.bindingEngine = new BindingEngine();        
        this.advertisersRepository = new AdvertisersRepository();
    }

    public Initialize($container: JQuery): AdvertisersView {
        this.$element = $("<div/>").appendTo($container);

        this.ViewModel = new AdvertisersListViewModel();
        this.advertisersRepository.GetAllAdvertisers().done((advertisers: Array<Model.Advertiser>) => {
            this.ViewModel.Advertisers(advertisers);
            this.ViewModel.IsReady(true);
        });

        this.bindingEngine.bindTemplate("AdvertisersListTemplate", this.$element, this.ViewModel);

        return this;
    }

    public Activate(): AdvertisersView {
        return this;
    }

    public Deactivate(): AdvertisersView {
        return this;
    }


    public Destroy(): AdvertisersView {
        this.$element.remove();
        return this;
    }

}