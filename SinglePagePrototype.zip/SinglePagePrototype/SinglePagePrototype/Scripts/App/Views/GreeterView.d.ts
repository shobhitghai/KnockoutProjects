export = GreeterView;
declare class GreeterView implements application.IView {
    private $element;
    private $span;
    private timerToken;
    constructor();
    public Initialize($container: JQuery): GreeterView;
    public Activate(): GreeterView;
    public Deactivate(): GreeterView;
    public Destroy(): GreeterView;
}
