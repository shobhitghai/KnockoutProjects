export = AccountsView;

import AccountsListViewModel = require("ViewModels/AccountsListViewModel");
import BindingEngine = require("BindingEngines/KendoBindingEngine");
import AccountsRepository = require("Services/Repository/AccountsRepository");

class AccountsView implements application.IView {

    private data: any;
    private $element: JQuery;
    public ViewModel: kendo.data.ObservableObject;

    private bindingEngine: application.IBindingEngine;
    private accountsRepository: AccountsRepository;

    constructor() {
        this.bindingEngine = new BindingEngine();
        this.accountsRepository = new AccountsRepository();
    }

    public Initialize($container: JQuery): AccountsView {
        this.$element = $("<div/>").appendTo($container);
        this.ViewModel = kendo.observable({accounts: [] });
        this.accountsRepository.GetAllAccounts().done((data) => {
            this.ViewModel = kendo.observable({ accounts: data });            
            this.Activate();
        });
        return this;
    }

    public Activate(): AccountsView {
        if ((<any>this.ViewModel).Accounts.length > 0) {            
            this.bindingEngine.bindTemplate("accountsListTemplateKendo", this.$element, this.ViewModel);
        }
        return this;
    }

    public Deactivate(): AccountsView {
        return this;
    }


    public Destroy(): AccountsView {
        this.$element.remove();
        return this;
    }

}