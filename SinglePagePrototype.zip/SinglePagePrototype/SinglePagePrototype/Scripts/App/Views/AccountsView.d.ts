export = AccountsView;
import AccountsListViewModel = require("ViewModels/AccountsListViewModel");
declare class AccountsView implements application.IView {
    private advertiserId;
    public ViewModel: AccountsListViewModel;
    private $element;
    private bindingEngine;
    private accountsRepository;
    private advertisersRepository;
    constructor(advertiserId?: number);
    public Initialize($container: JQuery): AccountsView;
    public Activate(): AccountsView;
    public Deactivate(): AccountsView;
    public Destroy(): AccountsView;
    private LoadAccounts();
    private LoadAdvertiser();
}
