export = AdvertisersView;
import AdvertisersListViewModel = require("ViewModels/AdvertisersListViewModel");
declare class AdvertisersView implements application.IView {
    private $element;
    public ViewModel: AdvertisersListViewModel;
    private bindingEngine;
    private advertisersRepository;
    constructor();
    public Initialize($container: JQuery): AdvertisersView;
    public Activate(): AdvertisersView;
    public Deactivate(): AdvertisersView;
    public Destroy(): AdvertisersView;
}
