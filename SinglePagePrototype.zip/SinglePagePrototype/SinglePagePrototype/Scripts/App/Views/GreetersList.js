define(["require", "exports", "Scripts/App/Greeter"], function(require, exports, GreeterImpl) {
    
    var GreetersList = (function () {
        function GreetersList(element, count) {
            this.count = count;
            this.greeters = new Array();
            for (var i = 0; i < count; i++) {
                var greeter = new GreeterImpl(element);
                this.greeters.push(greeter);
            }
        }
        GreetersList.prototype.start = function () {
            $.each(this.greeters, function (index, greeter) {
                greeter.start();
            });
        };
        return GreetersList;
    })();
    return GreetersList;
});
//# sourceMappingURL=GreetersList.js.map
