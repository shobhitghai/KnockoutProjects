define(["require", "exports", "App/Views/GreetersListView"], function(require, exports, GreetersListView) {
});
//# sourceMappingURL=GreeterListViewTest.js.map
