export = GreeterView;

class GreeterView implements application.IView {
    private $element: JQuery;
    private $span: JQuery;
    private timerToken: number;

    constructor() {}

    public Initialize($container: JQuery): GreeterView {
        this.$element = $("<div/>").text("The time is: ");
        this.$span = $("<span/>").text(new Date().toUTCString()).appendTo(this.$element);
        this.$element.appendTo($container);
        return this;
    }

    public Activate(): GreeterView {
        if (!this.$element) {
            throw new Error("View must be initialized before it can be activated");
        }
        this.timerToken = setInterval(()=> this.$span.text(new Date().toUTCString()), 500);
        return this;
    }

    public Deactivate(): GreeterView {
        clearTimeout(this.timerToken);
        return this;
    }

    public Destroy(): GreeterView {
        this.Deactivate();
        this.$element.remove();
        return this;
    }
}