﻿({
    name: "app",
    out: "app-optimized.js",
    paths: {
        "text": "../External/text"
    },
    optimize: "uglify2",
})