define(["require", "exports", "TestFramework/TestContext", "Mocks/Services/AccountsRepositoryMock", "Mocks/Services/AdvertisersRepositoryMock", "Mocks/BindingEngineMock"], function(require, exports, TestContext, RepositoryMock, AdvertiserRepositoryMock, BindingEngineMock) {
    suite("Accounts View", function () {
        var context;

        // Variables
        var bindingEngineMock;
        var repositoryMock;
        var advertiserRepositoryMock;
        var accountsView;
        var viewConstructor;
        var $container;

        // Top level initialization
        setup(function (done) {
            context = new TestContext();
            repositoryMock = new RepositoryMock(context);
            context.MockConstructor("Services/Repository/AccountsRepository", repositoryMock);

            advertiserRepositoryMock = new AdvertiserRepositoryMock(context);
            context.MockConstructor("Services/Repository/AdvertisersRepository", advertiserRepositoryMock);

            bindingEngineMock = new BindingEngineMock(context);
            context.MockConstructor("BindingEngines/KOBindingEngine", bindingEngineMock);

            context.Resolve("App/Views/AccountsView", function (accView) {
                viewConstructor = accView;
                done();
            });
            $container = $("<div/>");
        });

        // First second level fixture
        suite("Initialize method - No advertiser specified", function () {
            setup(function (done) {
                accountsView = new viewConstructor(null).Initialize($container);
                done();
            });

            test("Creates empty ViewModel", function () {
                expect(accountsView.ViewModel.Accounts()).to.be.empty();
                expect(accountsView.ViewModel.IsReady()).to.be.false();
                expect(repositoryMock.GetAllAccountsMock.Mock).to.be.calledOnce.ok();
            });

            test("Accounts loaded - View Model populated", function () {
                var accounts = [{ Id: 1 }, { Name: "name" }];
                repositoryMock.GetAllAccountsMock.Deferred.resolve(accounts);

                expect(accountsView.ViewModel.Accounts()).to.be.deep.equal(accounts);
                expect(accountsView.ViewModel.IsReady()).to.be.true();
            });

            test("BindingEngine bindTemplate is called with proper parameters", function () {
                repositoryMock.GetAllAccountsMock.Deferred.resolve();
                expect(bindingEngineMock.BindTemplateStub).to.be.calledOnce.ok();
                expect(bindingEngineMock.BindTemplateStub.args[0][0]).to.be.equals("AccountsListTemplate");
                expect(bindingEngineMock.BindTemplateStub.args[0][2]).to.be.equals(accountsView.ViewModel);
            });
        });

        // Second second level fixture
        suite("Initialize method - Advertiser specified", function () {
            var advertiserId = 2;
            setup(function (done) {
                accountsView = new viewConstructor(advertiserId).Initialize($container);
                done();
            });

            test("Accounts Repository called with AdvertiserId", function () {
                expect(repositoryMock.GetAdvertiserAccountsMock.Mock).to.be.calledOnce.ok();
                expect(repositoryMock.GetAdvertiserAccountsMock.Mock.args[0][0]).to.be.equal(advertiserId);
            });

            test("Accounts loaded - View Model populated", function () {
                var accounts = [{ Id: 1 }, { Name: "name" }];
                repositoryMock.GetAdvertiserAccountsMock.Deferred.resolve(accounts);

                expect(accountsView.ViewModel.Accounts()).to.be.deep.equal(accounts);
                expect(accountsView.ViewModel.IsReady()).to.be.true();
            });
        });
    });
});
//# sourceMappingURL=AccountsView-Test.js.map
