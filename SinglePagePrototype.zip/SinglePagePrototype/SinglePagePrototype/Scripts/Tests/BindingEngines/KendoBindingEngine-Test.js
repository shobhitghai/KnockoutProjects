define(["require", "exports", "TestFramework/TestContext", "Mocks/Services/TemplateLoaderMock"], function(require, exports, TestContext, TemplateLoaderMock) {
    // Top level fixture. Usually represent class
    suite("Kendo Binding Engine", function () {
        // Declare variables
        var context;

        var templateLoaderMock;
        var kendoBindingEngine;
        var kendoBindStub;

        // Setup for class level test. Called for each test
        setup(function () {
            context = new TestContext();

            // Create mock object.
            templateLoaderMock = new TemplateLoaderMock(context);

            // Inject mock object. next time code requests "Services/TemplateLoader" - the provided instance will be returned
            context.MockInstance("Services/TemplateLoader", templateLoaderMock);
        });

        // Inner suite. Represent set of use cases within class fixture.
        // Good example of usage is if several of tests require similar preparation to put class into require state.
        // Inner suite allows to do that preparation once for all those cases without affecting the others.
        suite("Bind Template - all parameters provided", function () {
            // Declare variables specific for inner suite.
            var $elem = $("<div/>");
            var viewModel = { data: "value" };

            // Prepare test run
            setup(function (done) {
                // Local mock. kendo is not loaded into test execution at all. So it's ok to just mock it directly
                kendoBindStub = sinon.stub();
                window.kendo = { bind: kendoBindStub };

                // Create system under test. since nothing can be done until system under test is created - use done() token to proceed when it's ready
                context.Resolve("BindingEngines/KendoBindingEngine", function (bindingEngine) {
                    kendoBindingEngine = new bindingEngine();
                    kendoBindingEngine.bindTemplate("SomeTemplate", $elem, viewModel);
                    done();
                });
            });

            // Test case. test case can be within suite on any level
            test("TemplateLoader.Load is called with proper parameters", function () {
                // Assertions build into phrases to explain themselves
                expect(templateLoaderMock.LoadTemplateStub.calledOnce).to.be.true();
                expect(templateLoaderMock.LoadTemplateStub.args[0][0]).to.be.equals("SomeTemplate");
            });

            test("Loading is Done - template inserted into element", function () {
                var template = "<script type='text/html' id='SomeTemplate'><div id='inner-element'/></script>";
                var $template = $(template).appendTo($("body"));
                templateLoaderMock.LoadTaskStub.resolve(template);

                expect($elem).to.have("#inner-element");

                $template.remove();
            });

            test("Loading is done - kendo.bind is called", function () {
                templateLoaderMock.LoadTaskStub.resolve("<div/>");

                expect(kendoBindStub).to.be.calledOnce.ok();
                expect(kendoBindStub.args[0][1]).to.be.equal(viewModel);
            });
        });
    });
});
//# sourceMappingURL=KendoBindingEngine-Test.js.map
