require.config({
    baseUrl: '../App',
    paths: {
        "App" : "./",
        "TestFramework": "../TestFramework",
        "Utils": "../Utils",
        "Tests": "../Tests",
        "Mocks": "../Mocks",
        "text": "../External/text",
        "squire": "../External/test/squire",
    }
});

mocha.setup("tdd");
var expect = chai.expect;
var Resources = {};

require([
    'Tests/BindingEngines/KendoBindingEngine-Test',
    'Tests/Accounts/AccountsView-Test'
], function () {

    mocha.run();
});
