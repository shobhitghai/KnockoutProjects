export = BindingEngineMock;

class BindingEngineMock implements application.IBindingEngine {
    
    public BindStub: SinonStub;

    public bind: ($element: JQuery, viewModel: any) => application.IBindingEngine;
    
    public BindTemplateTaskStub: JQueryDeferred<string>;
    public BindTemplateStub: SinonStub;
    public bindTemplate: (templateId: string, $element: JQuery, viewModel: any, templateModuleName?: string) => application.AsyncTask<string>;

    constructor(textContext: Tests.ITestContext) {
        this.BindStub = sinon.stub();
        this.bind = <any>this.BindStub;

        this.BindTemplateTaskStub = $.Deferred();
        this.BindTemplateStub = sinon.stub().returns(textContext.AsyncTaskBuilder.FromPromise(this.BindTemplateTaskStub.promise()));
        this.bindTemplate = <any>this.BindTemplateStub;
    }
}