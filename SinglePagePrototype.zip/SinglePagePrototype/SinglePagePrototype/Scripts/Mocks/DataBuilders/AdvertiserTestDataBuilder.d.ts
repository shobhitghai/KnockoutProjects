export = AdvertiserTestDataBuilder;
import AccountTestDataBuilder = require("DataBuilders/AccountTestDataBuilder");
declare class AdvertiserTestDataBuilder {
    private _data;
    constructor(seed?: number);
    public Build(): Model.Advertiser;
    public WithId(id: number): AdvertiserTestDataBuilder;
    public WithName(name: string): AdvertiserTestDataBuilder;
    public WithManager(accountManager: string): AdvertiserTestDataBuilder;
    public AddAccount(seed?: number, builderAction?: (builder: AccountTestDataBuilder) => {}): AdvertiserTestDataBuilder;
}
