define(["require", "exports"], function(require, exports) {
    

    var AccountTestDataBuilder = (function () {
        function AccountTestDataBuilder(seed) {
            seed = seed || 1;
            this._data = {
                CustomerId: seed,
                CustomerName: "Test Customer " + seed,
                AccountNumber: (1000 + seed) + "",
                AccountName: "Test Account" + seed,
                AccountStatus: 1 /* Draft */
            };
        }
        AccountTestDataBuilder.prototype.Build = function () {
            return this._data;
        };

        AccountTestDataBuilder.prototype.WithNumber = function (accNumber) {
            this._data.AccountNumber = accNumber;
            return this;
        };

        AccountTestDataBuilder.prototype.WithName = function (accName) {
            this._data.AccountName = accName;
            return this;
        };

        AccountTestDataBuilder.prototype.WithStatus = function (accStatus) {
            this._data.AccountStatus = accStatus;
            return this;
        };

        AccountTestDataBuilder.prototype.WithCustomer = function (customerId, customerName) {
            this._data.CustomerId = customerId;
            this._data.CustomerName = customerName;
            return this;
        };
        return AccountTestDataBuilder;
    })();
    return AccountTestDataBuilder;
});
//# sourceMappingURL=AccountTestDataBuilder.js.map
