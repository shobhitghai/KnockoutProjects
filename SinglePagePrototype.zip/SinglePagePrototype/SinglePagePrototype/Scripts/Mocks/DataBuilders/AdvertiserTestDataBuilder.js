define(["require", "exports", "DataBuilders/AccountTestDataBuilder"], function(require, exports, AccountTestDataBuilder) {
    

    // Data Builder - A centralized place to create an extity of a certain type.
    // Allows to keep all logic of building test entities in a single place and provide fluent API.
    // User by - Unit tests of Business Logic, Mock repositories
    var AdvertiserTestDataBuilder = (function () {
        // Constructor. Builds default entities by provided numeric seed
        function AdvertiserTestDataBuilder(seed) {
            seed = seed || 1;
            this._data = {
                CustomerId: seed,
                CustomerName: "Test Customer " + seed,
                AccountManager: "Account Manager " + seed,
                Accounts: [],
                Country: "Country " + seed,
                Language: "Language " + seed
            };
        }
        // Build method. Aggregates nd returns the result.
        AdvertiserTestDataBuilder.prototype.Build = function () {
            return this._data;
        };

        // Individual chainable methods.
        AdvertiserTestDataBuilder.prototype.WithId = function (id) {
            this._data.CustomerId = id;
            return this;
        };

        AdvertiserTestDataBuilder.prototype.WithName = function (name) {
            this._data.CustomerName = name;
            return this;
        };

        AdvertiserTestDataBuilder.prototype.WithManager = function (accountManager) {
            this._data.AccountManager = accountManager;
            return this;
        };

        // A chainable method to build dependent entity. Allows to specify a seed and builderAction to customize the added entity
        AdvertiserTestDataBuilder.prototype.AddAccount = function (seed, builderAction) {
            var builder = new AccountTestDataBuilder(seed);
            if (builderAction) {
                builderAction(builder);
            }
            this._data.Accounts.push(builder.Build());
            return this;
        };
        return AdvertiserTestDataBuilder;
    })();
    return AdvertiserTestDataBuilder;
});
//# sourceMappingURL=AdvertiserTestDataBuilder.js.map
