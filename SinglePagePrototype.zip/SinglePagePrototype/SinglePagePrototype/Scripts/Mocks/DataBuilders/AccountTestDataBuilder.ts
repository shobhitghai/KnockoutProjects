export = AccountTestDataBuilder

class AccountTestDataBuilder {

    private _data: Model.Account;

    constructor(seed?: number) {
        seed = seed || 1;
        this._data = {
            CustomerId: seed,
            CustomerName: "Test Customer " + seed,
            AccountNumber: (1000 + seed) + "",
            AccountName:"Test Account" + seed,
            AccountStatus: Model.AccountStatus.Draft
        };
    }

    public Build(): Model.Account {
        return this._data;
    }

    public WithNumber(accNumber: string): AccountTestDataBuilder {
        this._data.AccountNumber = accNumber;
        return this;
    }

    public WithName(accName: string): AccountTestDataBuilder {
        this._data.AccountName = accName;
        return this;
    }

    public WithStatus(accStatus: Model.AccountStatus): AccountTestDataBuilder {
        this._data.AccountStatus = accStatus;
        return this;
    }

    public WithCustomer(customerId?: number, customerName?: string): AccountTestDataBuilder {
        this._data.CustomerId = customerId;
        this._data.CustomerName = customerName;        
        return this;
    }

}