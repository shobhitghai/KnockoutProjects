export = AdvertiserTestDataBuilder

import AccountTestDataBuilder = require("DataBuilders/AccountTestDataBuilder");

// Data Builder - A centralized place to create an extity of a certain type.
// Allows to keep all logic of building test entities in a single place and provide fluent API.
// User by - Unit tests of Business Logic, Mock repositories
class AdvertiserTestDataBuilder {

    private _data: Model.Advertiser;

    // Constructor. Builds default entities by provided numeric seed
    constructor(seed?: number) {
        seed = seed || 1;
        this._data = {
            CustomerId: seed,
            CustomerName: "Test Customer " + seed,
            AccountManager: "Account Manager " + seed,
            Accounts: [],
            Country: "Country " + seed,
            Language: "Language " + seed            
        };
    }

    // Build method. Aggregates nd returns the result.
    public Build(): Model.Advertiser{
        return this._data;
    }

    // Individual chainable methods.
    public WithId(id: number): AdvertiserTestDataBuilder {
        this._data.CustomerId = id;
        return this;
    }

    public WithName(name: string): AdvertiserTestDataBuilder {
        this._data.CustomerName = name;
        return this;
    }

    public WithManager(accountManager: string): AdvertiserTestDataBuilder {
        this._data.AccountManager = accountManager;
        return this;
    }

    // A chainable method to build dependent entity. Allows to specify a seed and builderAction to customize the added entity
    public AddAccount(seed?: number, builderAction?: (builder: AccountTestDataBuilder) => {}): AdvertiserTestDataBuilder {
        var builder = new AccountTestDataBuilder(seed);
        if (builderAction) {
            builderAction(builder);
        }
        this._data.Accounts.push(builder.Build());        
        return this;
    }
   
}