export = AccountTestDataBuilder;
declare class AccountTestDataBuilder {
    private _data;
    constructor(seed?: number);
    public Build(): Model.Account;
    public WithNumber(accNumber: string): AccountTestDataBuilder;
    public WithName(accName: string): AccountTestDataBuilder;
    public WithStatus(accStatus: Model.AccountStatus): AccountTestDataBuilder;
    public WithCustomer(customerId?: number, customerName?: string): AccountTestDataBuilder;
}
