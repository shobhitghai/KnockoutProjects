﻿define(["require", "exports"], function(require, exports) {
    

    var TemplateLoaderMock = (function () {
        function TemplateLoaderMock(testContext) {
            this.testContext = testContext;
            this.LoadTaskStub = $.Deferred();
            this.LoadTemplateStub = sinon.stub().returns(this.testContext.AsyncTaskBuilder.FromPromise(this.LoadTaskStub.promise()));
            this.LoadTemplate = this.LoadTemplateStub;
        }
        TemplateLoaderMock.prototype.RegisterTemplate = function (templateId, template) {
            return;
        };
        return TemplateLoaderMock;
    })();
    return TemplateLoaderMock;
});
//# sourceMappingURL=TemplateLoaderMock.js.map
