define(["require", "exports", "Utils/AjaxWrapper", "Utils/AsyncTaskBuilder", "DataBuilders/AccountTestDataBuilder", "DataBuilders/AdvertiserTestDataBuilder"], function(require, exports, AjaxWrapper, AsyncTaskBuilder, AccountDataBuilder, DataBuilder) {
    

    var AdvertisersRepository = (function () {
        function AdvertisersRepository() {
        }
        AdvertisersRepository.prototype.GetAllAdvertisers = function () {
            var _this = this;
            return AsyncTaskBuilder.FromTimeout(function () {
                return _this.getMockAdvertisers();
            }, 2000);
        };

        AdvertisersRepository.prototype.GetAdvertiser = function (advertiserId) {
            var _this = this;
            return AsyncTaskBuilder.FromTimeout(function () {
                return _this.getMockAdvertisers().toQuery().first(function (advertiser) {
                    return advertiser.CustomerId == advertiserId;
                });
            }, 1000);
        };

        AdvertisersRepository.prototype.getMockAdvertisers = function () {
            return [
                new DataBuilder(1).AddAccount(1).AddAccount(101, function (builder) {
                    return builder.WithCustomer(1);
                }).AddAccount(102, function (builder) {
                    return builder.WithCustomer(1);
                }).Build(),
                new DataBuilder(2).AddAccount(2).AddAccount(201, function (builder) {
                    return builder.WithCustomer(2);
                }).Build(),
                new DataBuilder(3).AddAccount(3).Build(),
                new DataBuilder(4).AddAccount(4).Build()
            ];
        };
        return AdvertisersRepository;
    })();
    return AdvertisersRepository;
});
//# sourceMappingURL=AdvertisersRepositoryMockData.js.map
