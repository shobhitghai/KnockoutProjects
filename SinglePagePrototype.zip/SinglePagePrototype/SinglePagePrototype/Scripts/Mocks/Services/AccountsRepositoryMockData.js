define(["require", "exports", "Utils/AjaxWrapper", "Utils/AsyncTaskBuilder", "DataBuilders/AccountTestDataBuilder"], function(require, exports, AjaxWrapper, AsyncTaskBuilder, DataBuilder) {
    

    var AccountsRepository = (function () {
        function AccountsRepository() {
        }
        AccountsRepository.prototype.GetAllAccounts = function () {
            var _this = this;
            return AsyncTaskBuilder.FromTimeout(function () {
                return _this.getMockAccounts();
            }, 3000);
        };

        AccountsRepository.prototype.GetAdvertiserAccounts = function (advertiserId) {
            var _this = this;
            return AsyncTaskBuilder.FromTimeout(function () {
                return _this.getMockAccounts().toQuery().where(function (account) {
                    return account.CustomerId == advertiserId;
                }).toArray();
            }, 2000);
        };

        AccountsRepository.prototype.getMockAccounts = function () {
            return [
                new DataBuilder(1).Build(),
                new DataBuilder(101).WithCustomer(1).Build(),
                new DataBuilder(102).WithCustomer(1).Build(),
                new DataBuilder(2).Build(),
                new DataBuilder(201).WithCustomer(2).Build(),
                new DataBuilder(3).Build(),
                new DataBuilder(4).Build()
            ];
        };
        return AccountsRepository;
    })();
    return AccountsRepository;
});
//# sourceMappingURL=AccountsRepositoryMockData.js.map
