export = AdvertisersRepositoryMock;
declare class AdvertisersRepositoryMock implements Services.IAdvertisersRepository {
    private testContext;
    public GetAllAdvertisersMock: Tests.AsyncTaskMock<Model.Advertiser[]>;
    public GetAllAdvertisers: () => application.AsyncTask<Model.Advertiser[]>;
    public GetAdvertiserMock: Tests.AsyncTaskMock<Model.Advertiser[]>;
    public GetAdvertiser: (advertiserId: number) => application.AsyncTask<Model.Advertiser[]>;
    constructor(testContext: Tests.ITestContext);
}
