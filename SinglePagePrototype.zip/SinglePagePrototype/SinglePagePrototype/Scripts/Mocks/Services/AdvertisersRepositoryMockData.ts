export = AdvertisersRepository;

import AjaxWrapper = require("Utils/AjaxWrapper");
import AsyncTaskBuilder = require("Utils/AsyncTaskBuilder");
import AccountDataBuilder = require("DataBuilders/AccountTestDataBuilder");
import DataBuilder = require("DataBuilders/AdvertiserTestDataBuilder");

class AdvertisersRepository implements Services.IAdvertisersRepository {
    
    GetAllAdvertisers(): application.AsyncTask<Array<Model.Advertiser>> {
        return AsyncTaskBuilder.FromTimeout<Array<Model.Advertiser>>(() => {
            return this.getMockAdvertisers();
        }, 2000);
    }

    GetAdvertiser(advertiserId: number): application.AsyncTask<Model.Advertiser> {
        return AsyncTaskBuilder.FromTimeout<Model.Advertiser>(() => {
            return this.getMockAdvertisers().toQuery().first((advertiser)=> {
                return advertiser.CustomerId == advertiserId;
            });
        }, 1000);
    }


    private getMockAdvertisers(): Array<Model.Advertiser> {
        return [
            new DataBuilder(1)
                .AddAccount(1)
                .AddAccount(101, builder=> builder.WithCustomer(1))
                .AddAccount(102, builder=> builder.WithCustomer(1))
                .Build(),
            new DataBuilder(2)
                .AddAccount(2)
                .AddAccount(201, builder=> builder.WithCustomer(2))
                .Build(),
            new DataBuilder(3).AddAccount(3).Build(),
            new DataBuilder(4).AddAccount(4).Build()
        ];
    }

} 