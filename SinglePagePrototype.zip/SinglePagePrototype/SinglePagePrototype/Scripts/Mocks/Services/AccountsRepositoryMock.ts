export = AccountsRepositoryMock;

class AccountsRepositoryMock implements Services.IAccountsRepository {
        
    public GetAllAccountsMock: Tests.AsyncTaskMock<Array<Model.Account>>;
    public GetAllAccounts: () => application.AsyncTask<Array<Model.Account>>;
    
    public GetAdvertiserAccountsMock: Tests.AsyncTaskMock<Array<Model.Account>>;
    public GetAdvertiserAccounts: (advetiserId: number) => application.AsyncTask<Array<Model.Account>>;

    constructor(private testContext: Tests.ITestContext) {
        this.GetAllAccountsMock = testContext.GetAsyncTaskMock<Array<Model.Account>>();
        this.GetAllAccounts = <any>this.GetAllAccountsMock.Mock;        

        this.GetAdvertiserAccountsMock = testContext.GetAsyncTaskMock<Array<Model.Account>>();
        this.GetAdvertiserAccounts = <any>this.GetAdvertiserAccountsMock.Mock;        
    }
      
} 