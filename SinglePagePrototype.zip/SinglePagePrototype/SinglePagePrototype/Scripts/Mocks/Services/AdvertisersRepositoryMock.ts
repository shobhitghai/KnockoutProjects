export = AdvertisersRepositoryMock;

class AdvertisersRepositoryMock implements Services.IAdvertisersRepository {
        
    public GetAllAdvertisersMock: Tests.AsyncTaskMock<Array<Model.Advertiser>>;
    public GetAllAdvertisers: () => application.AsyncTask<Array<Model.Advertiser>>;

    public GetAdvertiserMock: Tests.AsyncTaskMock<Array<Model.Advertiser>>;
    public GetAdvertiser: (advertiserId: number) => application.AsyncTask<Array<Model.Advertiser>>;    


    constructor(private testContext: Tests.ITestContext) {
        this.GetAllAdvertisersMock = testContext.GetAsyncTaskMock<Array<Model.Account>>();
        this.GetAllAdvertisers = <any>this.GetAllAdvertisersMock.Mock;        

        this.GetAdvertiserMock = testContext.GetAsyncTaskMock<Array<Model.Account>>();
        this.GetAdvertiser = <any>this.GetAdvertiserMock.Mock;        
    }
      
} 