define(["require", "exports"], function(require, exports) {
    

    var AccountsRepositoryMock = (function () {
        function AccountsRepositoryMock(testContext) {
            this.testContext = testContext;
            this.GetAllAccountsMock = testContext.GetAsyncTaskMock();
            this.GetAllAccounts = this.GetAllAccountsMock.Mock;

            this.GetAdvertiserAccountsMock = testContext.GetAsyncTaskMock();
            this.GetAdvertiserAccounts = this.GetAdvertiserAccountsMock.Mock;
        }
        return AccountsRepositoryMock;
    })();
    return AccountsRepositoryMock;
});
//# sourceMappingURL=AccountsRepositoryMock.js.map
