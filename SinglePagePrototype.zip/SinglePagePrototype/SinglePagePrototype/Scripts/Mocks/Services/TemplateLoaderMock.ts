export = TemplateLoaderMock;

class TemplateLoaderMock implements Services.ITemplateLoader {

    public LoadTemplateStub: SinonStub;    
    public LoadTaskStub: JQueryDeferred<string>;    
    public LoadTemplate:(templateId: string, register: boolean, templateModuleName?: string) => application.AsyncTask<string>;


    constructor(private testContext: Tests.ITestContext) {
        this.LoadTaskStub = $.Deferred();
        this.LoadTemplateStub = sinon.stub().returns(this.testContext.AsyncTaskBuilder.FromPromise(this.LoadTaskStub.promise()));
        this.LoadTemplate = <any>this.LoadTemplateStub;
    }
     

    public RegisterTemplate(templateId: string, template: string): void {
        return;
    }    
}