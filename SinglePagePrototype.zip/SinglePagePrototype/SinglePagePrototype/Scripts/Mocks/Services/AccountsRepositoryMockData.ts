export = AccountsRepository;

import AjaxWrapper = require("Utils/AjaxWrapper");
import AsyncTaskBuilder = require("Utils/AsyncTaskBuilder");
import DataBuilder = require("DataBuilders/AccountTestDataBuilder");

class AccountsRepository implements Services.IAccountsRepository {
    
    public GetAllAccounts(): application.AsyncTask<Array<Model.Account>> {
        return AsyncTaskBuilder.FromTimeout<Array<Model.Account>>(()=> {
            return this.getMockAccounts();
        }, 3000);
    }

    public GetAdvertiserAccounts(advertiserId: number): application.AsyncTask<Array<Model.Account>> {
        return AsyncTaskBuilder.FromTimeout<Array<Model.Account>>(()=> {
            return this.getMockAccounts().toQuery().where((account)=> {
                return account.CustomerId == advertiserId;
            }).toArray();
        }, 2000);
    }


    private getMockAccounts(): Array<Model.Account> {
        return [
            new DataBuilder(1).Build(),
            new DataBuilder(101).WithCustomer(1).Build(),
            new DataBuilder(102).WithCustomer(1).Build(),
            new DataBuilder(2).Build(),
            new DataBuilder(201).WithCustomer(2).Build(),
            new DataBuilder(3).Build(),
            new DataBuilder(4).Build()
        ];
    }

} 