﻿export = TemplateLoaderMock;
declare class TemplateLoaderMock implements Services.ITemplateLoader {
    private testContext;
    public LoadTemplateStub: SinonStub;
    public LoadTaskStub: JQueryDeferred<string>;
    public LoadTemplate: (templateId: string, register: boolean, templateModuleName?: string) => application.AsyncTask<string>;
    constructor(testContext: Tests.ITestContext);
    public RegisterTemplate(templateId: string, template: string): void;
}
