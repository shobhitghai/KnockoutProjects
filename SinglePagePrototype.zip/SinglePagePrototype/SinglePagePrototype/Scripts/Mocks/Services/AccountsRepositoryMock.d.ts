export = AccountsRepositoryMock;
declare class AccountsRepositoryMock implements Services.IAccountsRepository {
    private testContext;
    public GetAllAccountsMock: Tests.AsyncTaskMock<Model.Account[]>;
    public GetAllAccounts: () => application.AsyncTask<Model.Account[]>;
    public GetAdvertiserAccountsMock: Tests.AsyncTaskMock<Model.Account[]>;
    public GetAdvertiserAccounts: (advetiserId: number) => application.AsyncTask<Model.Account[]>;
    constructor(testContext: Tests.ITestContext);
}
