﻿define(["require", "exports", "Utils/AsyncTaskBuilder", "DataBuilders/AccountTestDataBuilder"], function(require, exports, AsyncTaskBuilder, DataBuilder) {
    

    var AccountsRepository = (function () {
        function AccountsRepository() {
        }
        AccountsRepository.prototype.GetAllAccounts = function () {
            var _this = this;
            return AsyncTaskBuilder.FromTimeout(function () {
                return _this.getMockAccounts();
            }, 2000);
        };

        AccountsRepository.prototype.GetAdvertiserAccounts = function (advertiserId) {
            var _this = this;
            return AsyncTaskBuilder.FromTimeout(function () {
                return _this.getMockAccounts().toQuery().where(function (account) {
                    return account.CustomerId == advertiserId;
                }).toArray();
            }, 1000);
        };

        AccountsRepository.prototype.getMockAccounts = function () {
            return [
                new DataBuilder(1).Build(),
                new DataBuilder(101).WithCustomer(1).Build(),
                new DataBuilder(102).WithCustomer(1).Build(),
                new DataBuilder(2).Build(),
                new DataBuilder(201).WithCustomer(2).Build(),
                new DataBuilder(3).Build(),
                new DataBuilder(4).Build()
            ];
        };
        return AccountsRepository;
    })();
    return AccountsRepository;
});
//# sourceMappingURL=Copy of AccountsRepositoryMockData.js.map
