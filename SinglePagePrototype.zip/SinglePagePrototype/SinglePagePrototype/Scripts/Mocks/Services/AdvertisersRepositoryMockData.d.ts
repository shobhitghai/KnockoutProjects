export = AdvertisersRepository;
declare class AdvertisersRepository implements Services.IAdvertisersRepository {
    public GetAllAdvertisers(): application.AsyncTask<Model.Advertiser[]>;
    public GetAdvertiser(advertiserId: number): application.AsyncTask<Model.Advertiser>;
    private getMockAdvertisers();
}
