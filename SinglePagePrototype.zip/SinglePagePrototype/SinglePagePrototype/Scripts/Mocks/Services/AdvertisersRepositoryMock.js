define(["require", "exports"], function(require, exports) {
    

    var AdvertisersRepositoryMock = (function () {
        function AdvertisersRepositoryMock(testContext) {
            this.testContext = testContext;
            this.GetAllAdvertisersMock = testContext.GetAsyncTaskMock();
            this.GetAllAdvertisers = this.GetAllAdvertisersMock.Mock;

            this.GetAdvertiserMock = testContext.GetAsyncTaskMock();
            this.GetAdvertiser = this.GetAdvertiserMock.Mock;
        }
        return AdvertisersRepositoryMock;
    })();
    return AdvertisersRepositoryMock;
});
//# sourceMappingURL=AdvertisersRepositoryMock.js.map
