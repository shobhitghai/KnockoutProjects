export = BindingEngineMock;
declare class BindingEngineMock implements application.IBindingEngine {
    public BindStub: SinonStub;
    public bind: ($element: JQuery, viewModel: any) => application.IBindingEngine;
    public BindTemplateTaskStub: JQueryDeferred<string>;
    public BindTemplateStub: SinonStub;
    public bindTemplate: (templateId: string, $element: JQuery, viewModel: any, templateModuleName?: string) => application.AsyncTask<string>;
    constructor(textContext: Tests.ITestContext);
}
