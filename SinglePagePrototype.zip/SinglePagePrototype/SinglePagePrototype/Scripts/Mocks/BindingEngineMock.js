define(["require", "exports"], function(require, exports) {
    

    var BindingEngineMock = (function () {
        function BindingEngineMock(textContext) {
            this.BindStub = sinon.stub();
            this.bind = this.BindStub;

            this.BindTemplateTaskStub = $.Deferred();
            this.BindTemplateStub = sinon.stub().returns(textContext.AsyncTaskBuilder.FromPromise(this.BindTemplateTaskStub.promise()));
            this.bindTemplate = this.BindTemplateStub;
        }
        return BindingEngineMock;
    })();
    return BindingEngineMock;
});
//# sourceMappingURL=BindingEngineMock.js.map
