﻿$(function () {

    var flightViewModel = function () {
        var self = this;
        self.navShow = ko.observable(true);

        self.navigateToSection = function (tab) {
            $('html, body').animate({
                scrollTop: $('#'+ tab).offset().top
            }, 1000);
        };

       
        $('#search-result').kendoGrid({
            dataSource: {
                type: "json",
                transport: {
                    read: "../Content/searchResult.json"
                },
                pageSize: 10

            },
            columns: [{
                field: "flightId",
                title: "Flight Name",
                width: 140
            }, {
                field: "flightName",
                title: "Flight Name",
                width: 190
            }],
            height: 500,
            pageable: true
        });

        //$(document).scroll(function () {
        //    $(document).scrollTop() > 300 ? self.navShow(true) : self.navShow(false);
        //});
    };

    ko.applyBindings(new flightViewModel);


});